document.getElementById('bookingForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission

    // Get form values
    var destination = document.getElementById('destination').value;
    var departureDate = document.getElementById('departureDate').value;
    var returnDate = document.getElementById('returnDate').value;

    // Perform booking (here you would send data to backend or handle it as needed)
    var bookingStatus = document.getElementById('bookingStatus');
    bookingStatus.innerHTML = '<p>Booking in progress...</p>';

    // Simulate booking process (replace with actual backend communication)
    setTimeout(function() {
        bookingStatus.innerHTML = '<p>Booking successful!</p>';
    }, 2000); // Simulating a delay of 2 seconds
});